setwd("/home/agricolamz/Desktop/4_inst_phonetics")
df <- read.csv("stimuli_list.csv")
library(phonfieldwork)

rename_soundfiles(stimuli = df$stimuli,
                  prefix = "d1_",
                  path = "d1/")

rename_soundfiles(stimuli = df$stimuli,
                  prefix = "d2_",
                  path = "d2/")

concatenate_soundfiles(path = "d1/",
                       result_file_name = "d1_all")

concatenate_soundfiles(path = "d2/",
                       result_file_name = "d2_all")

annotate_textgrid(annotation =  df$stimuli,
                  textgrid = "d1/d1_all.TextGrid",
                  backup = FALSE)

annotate_textgrid(annotation =  df$stimuli,
                  textgrid = "d2/d2_all.TextGrid",
                  backup = FALSE)

create_subannotation(textgrid = "d1/d1_all.TextGrid",
                     tier = 1,
                     n_of_annotations = 9)

create_subannotation(textgrid = "d1/d1_all.TextGrid",
                     tier = 1,
                     n_of_annotations = 9)

create_subannotation(textgrid = "d2/d2_all.TextGrid",
                     tier = 1,
                     n_of_annotations = 9)

create_subannotation(textgrid = "d2/d2_all.TextGrid",
                     tier = 1,
                     n_of_annotations = 9)

annotate_textgrid(annotation = rep(c("", "u1", "", "u2", "", "u3", "", "cf", ""), 3),
                  textgrid = "d1/d1_all.TextGrid",
                  tier = 2,
                  backup = FALSE)

annotate_textgrid(annotation = rep(c("", "u1", "", "u2", "", "u3", "", "cf", ""), 3),
                  textgrid = "d2/d2_all.TextGrid",
                  tier = 2,
                  backup = FALSE)

vowel_annotation <- unlist(lapply(df$vowel, function(x) c(rep(c("", x), 4), "")))

annotate_textgrid(annotation = vowel_annotation,
                  textgrid = "d1/d1_all.TextGrid",
                  tier = 3,
                  backup = FALSE)

annotate_textgrid(annotation = vowel_annotation,
                  textgrid = "d2/d2_all.TextGrid",
                  tier = 3,
                  backup = FALSE)

draw_sound(file_name = "d1/d1_all.wav", annotation = "d1/d1_all.TextGrid",
           zoom = c(0, 10))

